//Employee Salary

#include<iostream>
using namespace std;

class Employee
{
	double salary;
	int n_hours;
	
    public:

	Employee()
	{}
	void getinfo()
	{
		cout << "Enter the salary: ";
		cin >> salary;
		cout << "Enter number of hrs: ";
		cin >> n_hours;
	}
	void Addsalary()
	{
		if (salary < 500)
			salary += 10;
	}
	void Addwork()
	{
		if (n_hours > 6)
			salary += 5;
	}
	void DisplaySalary()
	{
		cout << salary;
	}

};


int main()
{
	Employee empl;
		empl.getinfo();
		empl.Addsalary();
		empl.Addwork();

		cout << "\nFinal salary of employee: \n";
		empl.DisplaySalary();
}
