//Adding Amount in Piggbank

#include <iostream>
using namespace std;


class piggybank
{
    private : 
    int amount = 50;

    public :
    
    piggybank()
    {

    }
    
//Add Amount in piggbank

   piggybank(int i)
    {
        amount = i+amount;
    }
    
//Command to display  Final Amount

    void disp_amt()
    {
        cout<<amount<<endl;
    }
};

    int main()
    {
        piggybank i; 
        piggybank j(10);
        i.disp_amt();
        j.disp_amt();
    return 0;
    }
