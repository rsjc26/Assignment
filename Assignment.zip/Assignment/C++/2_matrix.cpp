// Generating the Matrix

#include <iostream>
using namespace std; 

class Matrix
{
        int  n1[50][50], n2[50][50], n3[50][50],n4[50][50];
        int  i, j, l, m,k;
        
        public :
        
        void takel()
        {
             cout<<"Enter number of rows :";
            cin>>l; 
        }
        
        void takem()
        {
            cout<<"Enter number of colunns :";
            cin>>m;
        }
        
        void setij()
        {
            cout<<"\n1st Matrix Input:\n";
            for(i=0;i<l;i++)
            {
                for(j=0;j<m;j++)
                {
                    cout<<"\nMatrix1["<<i<<"]["<<j<<"]=  ";
                    cin>>n1[i][j];
                }
            }
            
            cout<<"\n2nd Matrix Input:\n";
            for(i=0;i<l;i++)
            {
                for(j=0;j<m;j++)
                {
                    cout<<"\nMatrix2["<<i<<"]["<<j<<"]=  ";
                    cin>>n2[i][j];
                }
            } 
            
        }
        
        void addn()
        {
            //Addition of Matrice
            for(i=0;i<l;i++)
            {
                for(j=0;j<m;j++)
                {
                    n3[i][j]=n1[i][j]+n2[i][j];
                }
            } 
       
            cout<<"\nAddition of Matrix:\n";
            for(i=0;i<l;i++)
            {
                for(j=0;j<m;j++)
                {
                    cout<<"\t"<<n3[i][j];
                }
            cout<<endl;
            } 
            
        }
        void muln()
        {
            cout<<"\n Multiplication of Matrix:\n";
            for(i=0;i<l;i++)    
            {    
                for(j=0;j<m;j++)    
                {    
                    n4[i][j]=0;    
                    for(k=0;k<m;k++)    
                    {    
                        n4[i][j]+=n1[i][k]*n2[k][j];    
                    }    
                }    
            }    
            
            //printting Result   
            for(i=0;i<l;i++)    
            {    
                for(j=0;j<m;j++)    
                {    
                    cout<<"\t"<<n4[i][j];
                }    
                cout<<endl;    
            }
        }
    
};




int main() 
{  
    Matrix print;
    print.takel();
    print.takem();
    print.setij();
    print.addn();
    print.muln();
    
}
