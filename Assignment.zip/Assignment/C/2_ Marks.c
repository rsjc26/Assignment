#include<stdio.h>
void func(int a, int b, int c, int *total, float *per);
void main()
{
    int a, b, c,total;
    float per;

    printf("Enter the marks of subject 1: ");
    scanf("%d", &a);
    printf("Enter the marks of subject 2: ");
    scanf("%d", &b);
    printf("Enter the marks of subject 3: ");
    scanf("%d", &c);

    func(a, b, c, &total, &per);

    printf("\n Total Marks: %d", total);
    printf("\n Percentage: %.2f%%\n", per);
}

void func(int a, int b, int c, int *total, float *per)
{
    *total = (a+b+c);
    *per = ((a+b+c)/300.0)*100;
}
