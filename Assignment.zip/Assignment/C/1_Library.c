#include<stdio.h>
#include<string.h>
#include<stdlib.h>

struct Library
{
	int AccessionNo;
	char Title[50];
	char Author[50];
	float Price;
	int Flag;
};

int main(void)
{
	int n=0,Flag=1,r,k;	
	struct Library B[50];
	char Auth[50];
	n=0;
	while(Flag)
	{
		printf("\n ---------------Library Management System------------");
		printf("\n1. Add book information");
		printf("\n2. Display book information");
		printf("\n3. List all books of given author");
		printf("\n4. List the title of specidfied book");
		printf("\n5. List the count of books in the library");
		printf("\n6. List the books in the order of Accession Number");
		printf("\n7. EXIT\n");
		Flag=0;
		while(Flag<1 || Flag>7)
		{
			printf("Enter Choice: "); 
			scanf("%d",&Flag);
		}
		if(Flag==1)
		{
			printf("\nEnter Accession No.: "); 
			scanf("%d",&B[n].AccessionNo);
			
			printf("\nEnter Title        : "); 
			scanf("%s",B[n].Title);
			
			printf("\nEnter Author       : "); 
			scanf("%s",B[n].Author);
			
			printf("\nEnter Price        : "); 
			scanf("%f",&B[n].Price);
			
			printf("\nEnter Flag         : "); 
			scanf("%d",&B[n].Flag);
			
			printf("\nBook added successfully.");
			n=n+1;
		}
		
		if(Flag==2)
		{
			for(r=0;r<n;r++)
			{
				printf("\n%10d%10s%10s%10.2f",B[r].AccessionNo,B[r].Title,B[r].Author,B[r].Price);
				if(B[r].Flag) 	printf("\tNot Issued");
				else			printf("\tIssued");
			}
		}
		
		if(Flag==3)
		{
			printf("\nEnter Accession Number: "); 
			scanf("%ch",&Auth);
			for(r=0;r<n;r++)
			{
				if(strcmp(Auth,B[r].Author))
				{
					printf("\n%10d%10s%10s%10.2f",B[r].AccessionNo,B[r].Title,B[r].Author,B[r].Price);
					if(B[r].Flag) 	printf("\tNot Issued");
					else			printf("\tIssued");
				}
			}
		}
		if(Flag==4)
		{
			printf("\nEnter Accession Number: ");
			scanf("%d",&k);
			
			for(r=0;r<n;r++)
			{
				if(k==B[r].AccessionNo)
				{
					printf("\n%10d%10s%10s%10.2f",B[r].AccessionNo,B[r].Title,B[r].Author,B[r].Price);
					if(B[r].Flag) 
					printf("\tNot Issued");
					else		
					printf("\tIssued");
				}
			}
		}
		if(Flag==5)
		{
			printf("\nTotal No. of books in library = %d",n);
		}
		
		if(Flag==6)
		{
			for(r=0;r<n;r++)
			{
				printf("\n%10d%10s%10s%10.2f",B[r].AccessionNo,B[r].Title,B[r].Author,B[r].Price);
				if(B[r].Flag) 
				printf("\tNot Issued");
				else			
				printf("\tIssued");
			}
		}
		if(Flag==7) exit(0);


	}
	


}
