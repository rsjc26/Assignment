#include<stdio.h>

int main()
{
    
    int a[10],n, i,m, flag=0;
  
  	printf("\n Please Enter size of an array :  ");
  	scanf("%d",&n);
 
  	printf("\n Please Enter %d elements of an array: \n",n);
  	for(i = 0; i <n; i++)
   	{
   	 	scanf("%d",&a[i]);
   	}
	
	printf("\n Please Enter the search Element  :  ");
  	scanf("%d",&m);      
    
    
    for(int i=0;i<10;i++)
    {
        if (a[i]==m)
        {
            flag+=1;
            break;
        }
    
    }
    if (flag==0)
    {
        printf("NO\n");    
    }
    else
    {
        printf("YES\n");
    }
    for(int i=0;i<10;i++)
    {
        printf("\n%d",a[i]);
    }
}
