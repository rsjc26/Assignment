//In Place Mergering of Array

#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
#include<string.h>

int main()
{
    int a,b,c,temp;
    printf("Enter size of 1st array: ");
    scanf("%d",&a);
    printf("Enter the size of 2nd array: ");
    scanf("%d",&b);

    c=a+b;
    
    int m[a];
    int n[b];
    int i,j;

    printf("Enter Elements of 1st array:\n");
    for(i=0;i<a;i++)
    {
        printf("Elements of 1st array [ %d ]: ",i);
        scanf("%d",&m[i]);
    }

    printf("Enter elements of 2nd array:\n");
    for(i=0;i<b;i++)
    {
        printf("Elements of 2nd array [ %d ]: ",i);
        scanf("%d",&n[i]);
    }

    printf("Befor Sorting the elements are\n");

    printf("\nThe first array is: ");
    for(i=0;i<a;i++)
    {
        printf("%d ",m[i]);
    }

    printf("\nThe Second array is: ");
    for(i=0;i<b;i++)
    {
        printf("%d ",n[i]);
    }
    printf("\n");

//Merging the array

    int merge[c];
    
    
    for(i=0;i<a;i++)
    {
        merge[i]=m[i];
    }
    for(i=0,j=a;j<c && i<b;i++,j++)
    {
        merge[j]=n[i];
    }

    printf("The Merged array are: ");
    for(i=0;i<c;i++)
    {
        printf("%d ",merge[i]);
    }
    printf("\n");

    for(i=0;i<c;i++)
    {
        for(j=i+1;j<c;j++)
        {
            if(merge[i]>merge[j])
            {
                temp =merge[i];
                merge[i]=merge[j];
                merge[j]=temp;
            }
        }
    }

    printf("\nAfter Sorting the elements\n");
    printf("The sorted array is : ");
    for(i=0;i<c;i++)
    {
        printf("%d ",merge[i]);
    }
    printf("\n");

    for(i=0;i<a;i++)
    {
        m[i]=merge[i];
    }
    

    printf("The First array after sorting: ");
    for(i=0;i<a;i++)
    {
        printf("%d ",m[i]);
    }
    printf("\n");
    for(i=0,j=a;i<b,j<c;i++,j++)
    {
        n[i]=merge[j];
    }

    printf("The Second array after sorting: ");
    for(i=0;i<b;i++)
    {
        printf("%d ",n[i]);
    }
    printf("\n");
    return 0;
}
